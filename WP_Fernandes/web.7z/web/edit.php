<!DOCTYPE html>
<html>
<body>
<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "web";


$con = new mysqli($servername, $username, $password, $dbname);
// Check connection

 if(!isset($_POST['submit'])) {
   $q = "SELECT name, url, description, logo FROM info WHERE name = $_GET[name]";
   $result = mysqli_query($con,$q);
   $account = mysqli_fetch_array($result);
 }
?>
<form class="form-horizontal" action="edit_pro.php"  method="post">
                      
                        
                            <label>Name</label>
                          
                            <input type="text" class="form-control" name="name" value = "<?php echo $name['name']; ?>" />
                            <br>
                            <br>
                            <label>Twitter Name</label>
                          
                            <input type="text" class="form-control" name="url" value = "<?php echo $url['url']; ?>" />
                            <br>
                            <br>
                            <label>URL</label>
                          
                            <input type="text" class="form-control" name="description" value = "<?php echo $description['description']; ?>" />

                            <br>
                            <br>
                            <label>description/label>
                          
                            <input type="text" class="form-control" name="logo" style="width:450px" value = "<?php echo $logo['logo']; ?>" />

                            <br>
                            <br>

                       
                          
                                                    
                        
                       	  <input type="submit" class="btn btn-primary" value="Modify" />	
                          <button type="reset" class="btn btn-default">Cancel</button>      
                    
                  </form>
                 <!-- -->
         
          
      
           
</body>
</html>