<?php
require_once('TwitterAPIExchange.php');
/** Set access tokens here - see: https://dev.twitter.com/apps/ **/

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "web";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
$settings = array(
'oauth_access_token' => "352286133-8nfC7pLyLpCJOSikk7ZHIgQgnijo7IY2haa9SuXm",
'oauth_access_token_secret' => "VoS8BW1AXe6iWU1xZolTo2XYJsXCaIGZIL9NUYSwzbnAa",
'consumer_key' => "KVPeUEClXHAibZqfpp5zXuTow",
'consumer_secret' => "CqZ5e3Gvx5dNEvKKoFy2E69muGHzY7StwyuWF7IwWN4FzfCudY"
);
$url = "https://api.twitter.com/1.1/statuses/user_timeline.json";
$requestMethod = "GET";
if (isset($_GET['user']))  {$user = $_GET['user'];}  else {$user  = "KevinHart4Real";}
if (isset($_GET['count'])) {$count = $_GET['count'];} else {$count = 20;}
$getfield = "?screen_name=$user&count=$count";
$twitter = new TwitterAPIExchange($settings);
$string = json_decode($twitter->setGetfield($getfield)
->buildOauth($url, $requestMethod)
->performRequest(),$assoc = TRUE);
//if($string["errors"][0]["message"] != "") {echo "<h3>Sorry, there was a problem.</h3><p>Twitter returned the following error message:</p><p><em>".$string[errors][0]["message"]."</em></p>";exit();}

//$query2 = "DELETE FROM news WHERE url='www.twitter.com/KevinHart4Real'";     
//
//$result = mysql_query($query2);
    


foreach($string as $items)
    {
        echo "Time and Date of Tweet: ".$items['created_at']."<br />";
        echo "Tweet: ". $items['text']."<br />";
        echo "Tweeted by: ". $items['user']['name']."<br />";
        echo "Screen name: ". $items['user']['screen_name']."<br />";
        echo "Followers: ". $items['user']['followers_count']."<br />";
        echo "Friends: ". $items['user']['friends_count']."<br />";
        echo "Listed: ". $items['user']['listed_count']."<br /><hr />";

       // $query = "INSERT INTO news VALUES ('{$items['user']['name']}','www.twitter.com/KevinHart4Real',('".mysql_real_escape_string($items['text'])."'),'General')";     
      //$result = mysql_query($query);
        $sql = "INSERT INTO news (name, url, tweet, friends) VALUES ( '".
 $items['user']['name']."', '". $items['user']['url']."', '".
 $items['text']."', '". $items['user']['friends_count']."', '". $items['user']['friends_count']."')"; 
    }

    mysql_close();
?>